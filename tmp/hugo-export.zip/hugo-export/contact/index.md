---
title: Contact
author: admin
type: page
date: 2015-12-24T13:43:34+00:00
eltd_disable_footer_meta:
  - no
eltd_hide_background_image_meta:
  - no
eltd_show_title_area_meta:
  - no

---
\[vc\_row\]\[vc\_column\]\[vc\_single\_image image=&#8221;3250&#8243; img\_size=&#8221;full&#8221;\]\[/vc\_column\]\[/vc\_row\]\[vc\_row\][vc_column]

<div class="eltd-elements-holder eltd-responsive-mode-768" >
  <div class="eltd-elements-holder-item "  >
    <div class="eltd-elements-holder-item-inner">
      <div class="eltd-elements-holder-item-content eltd-elements-holder-custom-325167" style="padding: 0 20px">
        [vc_empty_space height=&#8221;38&#8243;]
        
        <div class="eltd-section-title-outer-holder" style="text-align: left">
          <div class="eltd-section-title-holder">
            <div class="eltd-section-title" style=";">
              Contact me
            </div>
          </div>
        </div>[vc_column_text]</p> 
        
        <h4>
          GET IN TOUCH
        </h4>
        
        <p>
          [/vc_column_text][vc_empty_space height=&#8221;20&#8243;][contact-form-7 id=&#8221;3043&#8243;][vc_empty_space height=&#8221;30&#8243;] <span class="eltd-icon-shortcode normal" style="margin: 0 20px 0 0" data-hover-color="#58bcb3" data-color="#888888"> <a href="https://vimeo.com/" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_vimeo eltd-icon-element" style="color: #888888;font-size:12px" ></span> </a> </span> <span class="eltd-icon-shortcode normal" style="margin: 0 20px 0 0" data-hover-color="#58bcb3" data-color="#888888"> <a href="http://instagram.com" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_instagram eltd-icon-element" style="color: #888888;font-size:12px" ></span> </a> </span> <span class="eltd-icon-shortcode normal" style="margin: 0 20px 0 0" data-hover-color="#58bcb3" data-color="#888888"> <a href="" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_twitter eltd-icon-element" style="color: #888888;font-size:12px" ></span> </a> </span> <span class="eltd-icon-shortcode normal"  data-hover-color="#58bcb3" data-color="#888888"> <a href="https://www.pinterest.com" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_pinterest eltd-icon-element" style="color: #888888;font-size:12px" ></span> </a> </span> </div> </div> </div></div>[/vc_column][/vc_row]
        </p>