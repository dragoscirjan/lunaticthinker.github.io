---
title: Home
author: admin
type: page
date: 2015-12-24T11:11:54+00:00
eltd_disable_footer_meta:
  - yes
eltd_hide_background_image_meta:
  - no
eltd_show_posts_per_page_meta:
  - 23
eltd_blog_slider_position_meta:
  - above_content_sidebar
eltd_blog_category_meta:
  - 6

---
