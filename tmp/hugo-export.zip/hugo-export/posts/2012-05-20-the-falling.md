---
title: The Falling
author: dragos
type: post
date: 2012-05-20T20:10:56+00:00
url: /index.php/the-falling/
categories:
  - The (round) line

---
I wonder which of you I desire more &#8211;
  
the one who struggles till the bitter end;
  
she fights alone to bear an entire world

Or this dreamy girl, beyond all that &#8211;
  
one I always see, but hidden beyond
  
the great and darken fortress walls&#8230;
  
and only with the corner of the eye &#8211;

The truth is I desire both &#8211; No matter which one<!--more-->


  
plays the hide and seek game with the other.

I wonder why I why I dream so much
  
of the sight of you in the morning &#8211;
  
Guess it’s just the spell you threw over me
  
while I imagined the taste of your lips
  
Or just the curse I gain while wondering alone,
  
exploring the roots of your soul

I dared reaching my hand to feel you,
  
Yet it was my only hand &#8211; my balance.
  
So I fell. <span style="color: #ffffff;">I’m falling for you&#8230;</span>