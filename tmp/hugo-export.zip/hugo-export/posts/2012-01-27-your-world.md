---
title: Your world
author: dragos
type: post
date: 2012-01-26T23:32:16+00:00
url: /index.php/your-world/
categories:
  - Red Wine

---
I&#8217;ve never been to your world &#8211;
  
the pages I have; they&#8217;re so few&#8230;
  
Would be a bless to learn of
  
Your blossom in this rose&#8217;s garden

Though time there is, I start to wonder;
  
descending near you &#8211; leaving
  
my endless world of nonsense&#8230;
  
Would ever help in growing a new path<!--more-->

Leave  to the new&#8230; never forget the old,
  
keep all the treasures to your soul
  
I&#8217;m was the watcher bid to see &#8211;
  
I dared to glimpse into your world &#8211;
  
I dared&#8230; I thought I would&#8230;

For so long, this rose appeared before me
  
So many times, so many shapes
  
Each time it grew more beautiful
  
that I could ever cherish it
  
Each time I was away
  
What right I have to&#8230;

I&#8217;ve never been to your world &#8211;
  
So little I know from my outpost
  
from the dark sea of the mind

The sky, it should remain untouched!
  
May never get to be in your world&#8230;