---
title: birth
author: dragos
type: post
date: 2012-02-10T16:22:53+00:00
url: /index.php/birth-of-the-dark/
categories:
  - Dark of the Moon Rose

---
_Will you marry me?_

She started packing things along the room;
  
While he was waiting on his knees
  
He thought he&#8217;ll never see her smile again
  
Got scared; than horrified he&#8217;d loose her &#8211;
  
So time was given for a choice &#8211; no repent
  
And then, when he&#8217;d expect it less
  
He saw the ring onto her hand &#8211; so shiny<!--more-->

Yet happy he was not; he also saw the end
  
Two thousand moons after that day&#8230;
  
He saw the wolves rising in armies
  
And demons walzing to his end!
  
He hoped he&#8217;d stop thad day from coming
  
But wrong he was&#8230; So wrong&#8230;

And so the day of ashes came &#8211; a day of beasts
  
So he gave up from hoping; took his nails
  
The wolves did not attack him though;
  
The demons gave him wine to drink &#8211;
  
And they all bowed into one question &#8211; &#8216;_my king?_&#8216; &#8211;
  
and then the world had opened to the beast