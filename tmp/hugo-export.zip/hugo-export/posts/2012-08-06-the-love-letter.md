---
title: the love letter
author: dragos
type: post
date: 2012-08-06T20:31:01+00:00
url: /index.php/the-love-letter/
categories:
  - Art of Life
  - The (round) line

---
are you the one?; the only soul I’d lay my head on &#8211; tell my tale
  
love letters sent to all the stars; I picked the moon &#8211; (green eyes and an) apple of sin
  
I wish I were the whispers on your lips; the shivers of you touch
  
nightingale &#8211; no music needed while around you, since
  
all I feel is music; you’re but the muse desired &#8211; never reached and craved&#8230;

and all I fear can be hidden in your heart; this long craved home
  
lying in all the words, and all the deeds; and all the unseen longings
  
I wish I were your morning smile; your radiating warmth while waking up &#8211;
  
nevertheless a dream is nothing but a dream &#8211; a question with no answer<!--more-->


  
are you the one?; the only soul I’d lay my heart on &#8211; give my life