---
title: The Craving
author: dragos
type: post
date: 2012-05-08T22:50:08+00:00
url: /index.php/the-craving/
categories:
  - The (round) line

---
If only I could crawl into this heart
  
Make it a home! make it a heaven&#8230;
  
I crave it&#8230; I _crave_ it! desire&#8230; and,
  
the most, I humbly fear _this_&#8230;
  
If I can&#8217;t have&#8230; than may the night
  
be cold! Forever dark, and darker moons&#8230;

I do not dare to break this world of yours
  
Could it be understood; never to see&#8230;
  
Yet every moment seems another drop<!--more-->


  
A cup of venom; this _snake_ is drowning
  
every little part &#8211; the ever wondering soul&#8230;

Pick up the glass! Observer, don&#8217;t let this fade
  
see if it&#8217;s worthy of your heart! See if this worlds
  
collided will give birth to other stars and _dream_!
  
I gladly stay! I&#8217;m opened! So cut _it_ open
  
if this would satisfy the need to know!

And I would drink this cup of venom; gladly!
  
If happines would bring to; yet even death
  
She&#8217;s weak! She has no powers over
  
The _dreams_ I bear for this white rose&#8230;

_Forever sealed the lips until the day
  
a kiss would break the word and set it free&#8230;
  
Would you, observer, be the one? _