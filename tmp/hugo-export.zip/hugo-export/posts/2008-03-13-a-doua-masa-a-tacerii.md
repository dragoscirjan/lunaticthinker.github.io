---
title: A doua masa a tacerii
author: dragos
type: post
date: 2008-03-13T12:00:06+00:00
url: /index.php/a-doua-masa-a-tacerii/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Am aprins lumanarile albastre la
  
auzul pasilor soaptelor tale prin pene.
  
ai ajuns la timp, dorule drag &#8211;
  
de fapt timpul s-a hotarat sa ramana
  
in urma, s-astepte&#8230;

Imbratisati, alaturi de vreme
  
am revenit la masa de stejar, de unde
  
timpul s-a scurs, mai imbatranit decat noi &#8211;
  
masa tacerii &#8211;<!--more-->


  
de data aceasta, insa, alaturi,
  
timpul nu mai e singur; prezenta lor
  
s-a materializat in fragede si mute semne.

vorbim in semne, cate o limba
  
pentru fiecare prezenta tacuta&#8230;
  
Vorbim in semne; Numaram semne!
  
Descifram semne inscrise pretutindeni
  
printre noi si&#8230; trecem &#8211;
  
trecem alaturi de ei si de timp.

La masa tacerii, dorule drag,
  
privesc cuvintele scrijelite-n semne, cu
  
ochii larg inchisi incalecati peste cerul,
  
in care stelele au inceput
  
sa se stinga&#8230;

tacerea e un loc neinceput &#8211;
  
la fel cina noastra mereu neterminata