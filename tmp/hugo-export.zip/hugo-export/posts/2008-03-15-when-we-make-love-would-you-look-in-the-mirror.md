---
title: When we make love, would you look in the mirror?
author: dragos
type: post
date: 2008-03-15T11:45:52+00:00
url: /index.php/when-we-make-love-would-you-look-in-the-mirror/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
E-o noapte nebuna&#8230;
  
Dincolo de zabrelele camerei tale
  
intrezaresc aceeasi femeie cu parfum argintiu;

Miroase-a tigari&#8230;
  
inca mai simt gustul buzelor tale
  
tragand din filtrul light&#8230;
  
Cearsaful sfasiat de ghearele noastre
  
zace incoltit de coapsele tale&#8230;
  
Asa de alb ti-e trupul, de-atatea framantari&#8230;<!--more-->


  
&#8211; de parca-ai murit.

Un iz, nou, de carne imi aduce aminte
  
de pumnul ce sfarama sanii
  
ca pe niste bulgari de pamant&#8230;

*

O mana coboara adanc pe sub carne&#8230;
  
o alta musca iarasi dintr-un san, pana la sange,
  
in timp ce gurile se fugaresc
  
precum doi copii,
  
iar apoi se imbratiseaza cu foame;
  
&#8211; poate ca ele sunt cele mai pure dintre toate&#8230;

*

De ce tremuri? A observat si tu
  
acele pene negre de la marginea patului?

Cred ca erau aripile noastre&#8230;

E-o noapte nebuna&#8230;
  
si dincolo de zabrelele camerei tale
  
mai e o femeie.
  
Si-acea femeie miroase a sange&#8230;

2008,03,08