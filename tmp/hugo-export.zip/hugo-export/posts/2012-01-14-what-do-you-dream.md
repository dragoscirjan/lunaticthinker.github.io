---
title: What do you dream?
author: dragos
type: post
date: 2012-01-13T22:06:04+00:00
url: /index.php/what-do-you-dream/
categories:
  - Red Wine

---
Still, the wine has an end. And the green dress
  
remains only a dream &#8211; one of the many;
  
The roses at your neck have the shape of a black orchid

So afraid I will not be able to tell you;
  
afraid I will never see the red moons,
  
afraid I will never gaze into the green&#8230;
  
And never the less I&#8217;m afraid!

<span style="color: #888888;">Afraid I will never be able to tell you my dreams.</span><!--more-->


  
<span style="color: #888888;">And I wonder! What do you dream!</span>

<span style="color: #888888;">Si totusi paharul de vin se termina. Si rochia verde ramane<br /> doar un vis printre multe alte dorinte;<br /> Iar colierul cu trandafiri a capatat forma unei orhidee negre</span>

<span style="color: #888888;">Mi-e teama ca nu voi avea curajul sa-ti spun;<br /> Mi-e teama ca lunile nu le voi mai prinde rosii,<br /> Mi-e teama ca ochii se vor pierde iara in verde&#8230;<br /> Si nu in cele din urma mi-e teama!</span>

<span style="color: #888888;">Mi-e teama ca nu voi avea curajul sa iti spun ce visez.<br /> Si ma intreb! Oare care-s visele tale?</span>