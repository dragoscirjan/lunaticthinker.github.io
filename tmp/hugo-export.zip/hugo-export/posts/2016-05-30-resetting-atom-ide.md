---
title: Resetting Atom IDE
author: dragos
type: post
date: 2016-05-30T07:25:08+00:00
url: /index.php/resetting-atom-ide/
featured_image: http://lunaticthinker.me/wp-content/uploads/2016/05/atom.jpg
categories:
  - "Coder's Grave"
  - Home Page
  - IDE
  - Linux in a Box

---
Too often now, my [Atom][1] setup fails to load giving the following message: 

Not a permanent solution, but one to help you move on, is resetting the window state.

<pre>atom --clear-window-state</pre>

 [1]: https://atom.io