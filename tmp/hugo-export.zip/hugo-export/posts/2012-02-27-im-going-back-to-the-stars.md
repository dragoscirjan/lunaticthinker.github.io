---
title: I’m going back to the stars…
author: dragos
type: post
date: 2012-02-27T01:05:27+00:00
url: /index.php/im-going-back-to-the-stars/
categories:
  - Red Wine

---
So! I think it&#8217;s time I quit talking babbles; even though
  
I&#8217;m pretty sure that every word I&#8217;m saying is like
  
an open book to you; like you are to me when I&#8217;m around you

It&#8217;s time I put this in the words of a man; not a lover
  
not a story teller; not a boy and certainly not a poet &#8211;
  
Poets are shallow these days&#8230; natural deceivers
  
So I&#8217;ll try to put this story in my own words.

_There&#8217;s not a moment going by, that I don&#8217;t think of you<!--more-->


  
That I try to put my thoughts in order, yet you are
  
the only link to my sanity &#8211; You give me a quiet mind and I&#8230;_

No, I was never good at defining this feeling
  
All I know is that, the vision of our glass of wine is
  
as peaceful as taking a glimpse at the stars and
  
as warm as all the fires of the world gathered up in one sun
  
And that every time I think of, the world narrows

_I dreamt I kissed you; and it was like getting bourn again
  
So sweet that I could feel the shivers in the tip of my fingers&#8230;_

I know! I know it is just a dream, but that doesn&#8217;t deprive
  
me from the right to hope &#8211; And I hope! I hope and I wish
  
so hard that I could crush the stars with only one word;
  
but this power will not; will never apply on will&#8230;

I&#8217;ve wondered so much what I should do to win you,
  
you heart, your soul, your essence &#8211; the light of this
  
is too violent, too unstable and I cannot control it.

When I&#8217;m around you, I lose myself&#8230; I&#8217;m like a little boy
  
always wanting to play; always growling; always unable to
  
find his own words! So I&#8217;ve decided to leave myself for a while
  
get back to the points of origin; back to my world hidden
  
in plain sight. And I will look upon myself and grow&#8230;

So&#8230; you can say I&#8217;m going back to the stars; but not alone
  
I&#8217;m gonna take with me every little thought &#8211; every
  
little dream I have about you; about me not knowing what
  
I want about you, for you, for us&#8230;
  
I do not want to ask again if you think or _will_ think of me

I wish you do! i would be such a fool man to say that I don&#8217;t
  
And if you&#8217;ll miss me, just light a candle; let it
  
wear your whispers to my ears&#8230; or maybe send a rose