---
title: Larg închis
author: dragos
type: post
date: 2016-06-23T09:58:43+00:00
url: /index.php/larg-inchis/
categories:
  - Rosu

---
Spunea ca şi-a închis ochii şi
  
a uitat cerul printre pântece &#8211; hăul
  
l-a cuprins în căderea-i spre ea &#8211;
  
Înnebunit, şi-a pironit sinele în
  
vârful cel mai de sus &#8211; sub sine

Miroase a ploaie rânceda, spunea &#8211;
  
parfum de roşu revărsat din trupul
  
ultimului înger a cărui amintire hâdă
  
am păstrat-o &#8211; negură unui abis mut

<p style="text-align: right;">
  2006-07-17
</p>