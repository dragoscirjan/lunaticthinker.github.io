---
title: The little roses
author: dragos
type: post
date: 2012-01-11T00:25:40+00:00
url: /index.php/the-little-roses/
categories:
  - Red Wine

---
Watching you sip from the red wine startles my heart
  
I do not know if our silence or our inner gaze,
  
or if our long talks, our game of words
  
born from  the need to tease, do startle me
  
as if I am a bare child waiting for a gift!

I wonder whether one of us does care about
  
the talk. We let it flow&#8230;
  
We test each other; how far can we go
  
Should there be safety words for us!<!--more-->

So beautiful in your green dress; so close to the red of the wine
  
so beautiful the red of the necklace of roses under your dark hair

<span style="color: #888888;">Privindu-te cum sorbi din licoarea rosie, imi tresare inima<br /> Nu stiu daca,  fie tacerea dintre noi, pauzele pe care le facem<br /> pentru a privi introspectiv<br /> Fie discutiile lungi, jocul de cuvinte ce se naste<br /> din dorinta de-al incolti pe celalalt,<br /> ma face sa tresar precum un copil inaintea unei surprize.</span>

<span style="color: #888888;">Ma-ntreb daca vreunuia dintre noi chiar ii pasa<br /> de subiectele abordate care le lasa sa curga<br /> Mai degraba fiecare testeaza pragul celuilalt &#8211; de toleranta<br /> Poate ca ar trebui sa existe un cuvant de siguranta<br /> si in astfel de jocuri.</span>

<span style="color: #888888;">Te prinde atat de bine rochia verde, roseata paharului de vin<br /> completata de micii trandafiri de la gat, aproape ascunsi in parul de abanos &#8230;</span>