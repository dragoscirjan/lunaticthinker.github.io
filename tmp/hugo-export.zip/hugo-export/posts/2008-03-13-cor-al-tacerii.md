---
title: Cor al tacerii
author: dragos
type: post
date: 2008-03-13T11:59:21+00:00
url: /index.php/cor-al-tacerii/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Lupta din noi tine de ere&#8230;
  
Atunci aveam aripi &#8211;
  
S-au scuturat cu fiecare lovitura
  
ce ne-am oferit-o ca pe un dar
  
in zi de sarbatoare .
  
Au ramas doua perechi de crengi uscate,
  
frante la cele mai mici adieri
  
ale durerii&#8230;

Ingerii au uitat de noi<!--more-->


  
Ne-au lasat ferecati printre
  
statuete de ceara albastra&#8230;
  
A trecut luna.
  
A trecut si zborul pagan!
  
A ramas doar un cor al tacerii

Furiile-au stagnat obosite
  
in peretii de vanata piatra &#8211;
  
acum se retrag bantuite&#8230;