---
title: The Tourment
author: dragos
type: post
date: 2012-04-28T08:39:59+00:00
url: /index.php/the-tourment/
categories:
  - The (round) line

---
The staying away! Not speaking&#8230;. Not telling how my heart jumps whenever&#8230;
  
I wish I could scream it! And yes, I&#8217;m so selfish! I say I and I again
  
and again! Not asking&#8230; Not daring to think
  
Not wanting to know the already obvious answer&#8230;

A thousand moons! An army of demons&#8230; the soul of a wolf
  
No curse&#8230; no magic stronger than the heart of <span style="text-decoration: underline;">another</span>
  
The waltz has no purpose! The march lost its meaning
  
It only remains in the form of a nightmare
  
The pain that will never heal but will be forgotten&#8230;<!--more-->

And yet the dream! The tourmenting of the sweetness
  
The almost kiss, the taste, the softness! The <span style="text-decoration: underline;">shiver</span> &#8230;
  
And then the wake up&#8230; The almost touch of the skin&#8230;
  
The scent&#8230; the perfume left on my hands&#8230;
  
Craziness! Madness&#8230;. Tourment&#8230; Pain! Yet I am happy!
  
_I feel_! Trapped, not wishing for an escape; For there is but one&#8230;
  
Happiness is useless if not shared&#8230;