---
title: AL DOILEA RAU
author: dragos
type: post
date: 2012-12-26T23:09:17+00:00
url: /index.php/al-doilea-rau/
categories:
  - O linie franta in doi

---
S-a nascut cand metafora
  
n-a mai putut tine loc cuvantului
  
Cand timpul s-a rupt &#8211; in doua,
  
apoi in noua, in saptezeci si noua

A muscat apoi, cu pofta, din viata,
  
cand noi incepeam sa ne stingem
  
Cand eu am ales, prefacut in apus,
  
sa ard &#8211; am dat foc mesei tacerii;
  
Singurul mod de a ma razvrati, de altfel<!--more-->

Comunicam prin tacere &#8211;
  
prin vibratiile fiintei pe care
  
am risipit-o acum intru nicaieri,
  
transformat intr-o stana de piatra.
  
Dar si acesta era o forma de a raspunde &#8211;
  
Si-atunci&#8230; am ales sa ma transform
  
in mormant&#8230;

&#8211;

_**Tu**, Dumnezeu ce-ai ucis o fecioara!_
  
_**Tu**, ia acest pumnal infometat de viata,_
  
_hraneste-l cu sangele fierbinte_
  
_din pieptul celui care arde intru mantuire_
  
_Nu e blestem &#8211; al doilea rau in asta lume_
  
_mai crunt &#8211; ferice tie gand, pierdut_
  
_in nestiinta &#8211; ferice tie, fiara_
  
_Caci rugaciunea-i intr-u cazna_
  
_Celui ce-a pierdut! **Tu**! N-ai sa stii_
  
_Ce lupta&#8230;_