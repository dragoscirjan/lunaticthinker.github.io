---
title: Linux 2 USB Flash Drive
author: dragos
type: post
date: 2009-11-17T17:20:48+00:00
url: /index.php/linux-2-usb-flash-drive/
categories:
  - Uncategorized

---
I&#8221;ve always looked for a tool to put an ISO Linux to a Flash USB Drive.

http://unetbootin.sourceforge.net<!--more-->

This will help you a lot. Supports all major distro and has versions for both Linux and Windows.

<img class="alignnone" src="http://sourceforge.net/dbimage.php?id=167328" alt="" width="542" height="397" />