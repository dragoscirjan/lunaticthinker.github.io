---
title: Mendeleev is overrated!
author: dragos
type: post
date: 2011-02-02T13:01:29+00:00
url: /index.php/mendeleev-is-overrated/
categories:
  - Uncategorized

---
Dudes, I&#8217;ve just discovered that Mendeleev&#8217;s periodical table is totally overrated! Yes&#8230; a new periodical table has been discovered!

Behold! <a href="http://code.google.com/more/table/" target="_blank" rel="noopener noreferrer">GOOGLE&#8217;s PERIODICAL TABLE</a>!

Now&#8230; leaving the jokes behind, the idea is very good. +1 point to Google for thinking out smart. It&#8217;s very easy now, to discover their APIs without too much trouble.