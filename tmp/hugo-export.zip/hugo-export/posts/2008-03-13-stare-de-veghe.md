---
title: Stare de veghe
author: dragos
type: post
date: 2008-03-13T11:59:01+00:00
url: /index.php/stare-de-veghe/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Culcat la capatul unui pat de pleoape
  
sterse de lacrimi ce au fost si-au sa vina
  
cu acelasi anotimp al plansului de mov&#8230;
  
astept&#8230;

Curg nori pietrificati in cuvinte dematerializate &#8211;
  
Peretii lasacasului nostru s-au topit in cantecul
  
unei valtori, curgand cascade peste randuri albastre
  
Cui sa te dau! Cui sa te am? Cui sa te doresc!
  
visez&#8230;<!--more-->

Stare de doi despartiti de rutina unei dimineti in care,
  
ca intodeauna, soarele a mai rasarit o data doar ca sa apuna&#8230;
  
obosit&#8230;