---
title: Pictand Rasarituri
author: dragos
type: post
date: 2016-01-13T23:20:36+00:00
url: /index.php/pictand-rasarituri/
featured_image: http://lunaticthinker.me/wp-content/uploads/2016/01/image.jpg
categories:
  - O linie franta in doi

---
<p style="text-align: right;">
  <em>For days that I&#8217;m calling you</em><br /> <em> The light of the day is true</em><br /> <em> Yes, we&#8217;re hopeless</em><br /> <em> Do you think we lost it?</em><br /> https://www.youtube.com/watch?v=Z87arO2T-Yo
</p>

Purtand o carte veche-n buzunarul hainii
  
Cu ochii-n rasarit, in umbra unei feline albe
  
Ingenuncheat in urma unei soapte…

Penita scrijelind hartia &#8211; infuriata de propriul strigat
  
In disperare aruncat, ravasul se scufunda

Pictand rasarituri, cu ochii larg inchisi
  
Soptindu-ti o ruga, cu-o unghie insangerata

Ma sufoc in propria rasuflare

Iertare

Ma iarta
  
Pentru o vreme am sa ma retrag
  
sa fumez tigara imbibata in sange
  
Stii tu, cea pe care o tineam in mana
  
cand ti-am rupt venele cu dintii

<p style="font-size: 9px; text-align: right;">
  Paiting: <a href="https://afremov.com/AWAY-FROM-THE-SUNSET-PALETTE-KNIFE-Oil-Painting-On-Canvas-By-Leonid-Afremov-Size-30-X36.html"><br /> AWAY FROM THE SUNSET — PALETTE KNIFE Oil Painting On Canvas By Leonid Afremov &#8211; Size 36&#8243;X30&#8243;</a>
</p>