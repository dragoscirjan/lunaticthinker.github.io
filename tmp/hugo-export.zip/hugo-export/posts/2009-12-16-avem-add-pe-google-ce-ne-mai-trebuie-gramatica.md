---
title: Avem add pe google, ce ne mai trebuie gramatica…
author: dragos
type: post
date: 2009-12-16T05:46:49+00:00
url: /index.php/avem-add-pe-google-ce-ne-mai-trebuie-gramatica/
aktt_notify_twitter:
  - no
categories:
  - Uncategorized

---
[<img class="aligncenter size-full wp-image-183" title="google-add" src="http://35.224.157.168/wp-content/uploads/2009/12/google-add.png" alt="google-add" width="311" height="266" srcset="https://lunaticthinker.me/wp-content/uploads/2009/12/google-add.png 311w, https://lunaticthinker.me/wp-content/uploads/2009/12/google-add-300x257.png 300w" sizes="(max-width: 311px) 100vw, 311px" />][1]<!--more-->

[<img class="aligncenter size-full wp-image-194" title="google-add2" src="http://35.224.157.168/wp-content/uploads/2009/12/google-add2.png" alt="google-add2" width="313" height="267" srcset="https://lunaticthinker.me/wp-content/uploads/2009/12/google-add2.png 313w, https://lunaticthinker.me/wp-content/uploads/2009/12/google-add2-300x256.png 300w" sizes="(max-width: 313px) 100vw, 313px" />][2]

Sa mai si incercuiesc?

 [1]: http://35.224.157.168/wp-content/uploads/2009/12/google-add.png
 [2]: http://35.224.157.168/wp-content/uploads/2009/12/google-add2.png