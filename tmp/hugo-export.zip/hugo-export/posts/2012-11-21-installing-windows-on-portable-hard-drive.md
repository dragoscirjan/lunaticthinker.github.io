---
title: Installing Windows on Portable Hard Drive
author: dragos
type: post
date: 2012-11-21T18:34:09+00:00
url: /index.php/installing-windows-on-portable-hard-drive/
categories:
  - Other OSs

---
We needed to do such thing a few days ago, for one of our coleagues, and this helped a lot. Hope it will help you as well.<!--more-->


  
[youtube video_id=&#8221;wSBIcNmCAX0&#8243;]