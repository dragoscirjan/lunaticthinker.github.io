---
title: Fluturi blestemati
author: dragos
type: post
date: 2012-11-18T23:39:17+00:00
url: /index.php/fluturi-blestemati/
categories:
  - Art of Life
  - O linie franta in doi

---
Pluteam aieve-n umbra pasului marunt
  
Tu, agatata de bratele lui, eu &#8211; eu priveam
  
Albastrul cerului ochilor sai pervestea furtuna

Jocuri de cuvinte &#8211; intotdeauna cerul, ori pamantul&#8230;
  
Ori cerul&#8230; Nu exista oras sa-ncapa &#8211;
  
Tunetul, cand norii de sub noi, marunte&#8230;
  
atat de marunte si-atat de multe&#8230;
  
de fulgere-aruncate &#8211;
  
ganduri amare de-odinioara si-un pahar<!--more-->

Otrava, pelinul de pe aripi, intr-o lume seaca;
  
Pluteam aieve-n urma pasului marunt;
  
Tu erai prinsa-n mrejele macilor din soare
  
Nu era lume sa nu fi pustiit &#8211; drumul spre casa
  
Si totusi nicaieri nu e ca in imbratisare&#8230;
  
Iar acasa&#8230; acasa e doar un zvon!

Paseam tacut, in urma ta, aieve
  
Purtandu-ti trena din fluturi blestemati
  
Albastri &#8211; as fi tremurat cerul &#8211; am ucis
  
atatea lumi fara sa putem gasi drumul

&#8211;

Ne-am despartit&#8230; eu am ales pamantul
  
ei au ales&#8230; am colindat fiece fir de praf
  
singura cale spre liniste-ntre umbre &#8211;
  
in cautarea mormantului din fum
  
Si-am transformat tot haul intru unul
  
si singur loc spre veci &#8211; sub mantia de
  
fluturi blestemati&#8230;