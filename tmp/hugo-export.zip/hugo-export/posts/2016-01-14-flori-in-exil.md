---
title: Flori in exil
author: dragos
type: post
date: 2016-01-13T23:18:53+00:00
url: /index.php/flori-in-exil/
featured_image: http://lunaticthinker.me/wp-content/uploads/2016/01/amaranth_by_shhadowfang-d586j3e.jpg
categories:
  - O linie franta in doi

---
Sa te intreb de-ai vazut vreodata un inger;
  
sa ma-ndoiesc; tu nu crezi
  
Pierdut in exil printre nori ai ales sa privesti,
  
sa zambesti &#8211; niciodata s-atingi&#8230;

Azi am infulecat un demon &#8211; biet trandafir in exil
  
Am sarit la gatul sau precum o fiara
  
iar sangele sau mi-a curs printre colti
  
in suvoaie de rosu

Sunt ca un sclav cerandu-ti hrana
  
_cand hrana sa-i sarutul tau de fum_
  
cand hrana sa esti tu
  
La sanul tau pierdut as sta o vesnicie
  
pierdut in crunta liniste si vis amar

Am renascut &#8211; un demon; mi-au crescut
  
colti si gheare si-s imbatat in rosu
  
Numele meu, e patru &#8211; fara de unul,
  
pierdut in exil&#8230;

<p style="text-align: right; font-size: 9px;">
  Picture author: <a href="http://liljan-laulu.deviantart.com/art/Amaranth-316072490">http://liljan-laulu.deviantart.com</a>
</p>