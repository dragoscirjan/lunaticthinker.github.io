---
title: A murit Arthur C. Clarke
author: dragos
type: post
date: 2008-03-19T12:31:04+00:00
url: /index.php/a-murit-arthur-c-clarke/
categories:
  - Ganduri

---
<img src="http://dor.homelinux.com/wp/wp-content/uploads/2008/03/arthurcclarke.jpg" alt="Arthur C. Clarke" hspace="4" vspace="4" align="right" />E ciudat sa incepi o sectiune dintr-un blog cu un articol rau &#8211; un articol despre moartea unui om, dar&#8230; uite ca s-a intamplat, desi urasc din toata inima lucrul asta.

_**Marele scriitor** **SF****, de origine englez,** ******<span class="yshortcuts" style="border-bottom: 1px dashed #0066cc; background: transparent none repeat scroll 0% 50%; cursor: pointer; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial">Sir Arthur C Clarke</span> a murit in <span class="yshortcuts" style="border-bottom: 1px dashed #0066cc; cursor: pointer">Sri Lanka</span> la varsta de 90 de ani.**_

_Nascut in Somerset, el a devenit faimos in 1968 dupa ce a scris o proza scurta intitulata Santinela (<span class="yshortcuts" style="border-bottom: 1px dashed #0066cc; cursor: pointer">The Sentinel</span>) care apoi a facut parte din filmul aparut in 2001: Odiseea Spatiala, de <span class="yshortcuts" style="border-bottom: 1px dashed #0066cc; cursor: pointer">Stanley Kubrick</span>._ 

_Moartea marelui scriitor a survenit la ora 1:30 dupa un atac cardio &#8211; respiratoriu._

Ne relateaza <a href="http://news.bbc.co.uk/2/hi/uk_news/7304004.stm" target="_blank" rel="noopener noreferrer">BBC</a>.<!--more-->

<a href="http://bocancul-literar.ro/user/batoriada" target="_blank" rel="noopener noreferrer">Slivia Bitere</a> comenteaza stirea pe Bocancul Literar asftel:
  
_Sunt multe de spus despre acest Sir Arthur C Clarke dar este bine ca cineva s-a gândit sa lase câteva rânduri aici pe bocanc pentru ce au însemnat scriiturile sale, pentru iubitorii SF.
  
La 90 de ani esti chiar batrân dar este exact acel amar când îti moare cineva drag din neamul tau. Durerea ramâne, exista pentru ca se leaga direct de fiinta ta si-atunci si 101 ani tot mi se par tristi&#8230;_ 

Eu nu mai pot spune nimic.
  
Pentru mine a fost unul dintre cei mai mari scriitori de Science Fiction. L-am ridicat pe un piedestal inalt pe acest om, dupa ce am citit nuvele ca _The Star, Transcience, Cradle_. Un piedestal pe care nu a mai urcat nimeni pana acum, oricat de mult mi-ar fi placut scriitura si ideile. A ramas un idol pentru mine&#8230; Va ramane mereu astfel.

![gnome-mime-application-x-bzip.png][1][Transcience, Arhtur C. Clarke][2]
  
![gnome-mime-application-x-bzip.png][1][The Star, Arthur C. Clarke][3][
  
][4]{#file-link-13.file-link.text} ![gnome-mime-application-x-bzip.png][1][Cradle, Arthur C. Clarke][5][
  
][4]{#file-link-13.file-link.text} [][4]{#file-link-13.file-link.text}

 [1]: http://dor.homelinux.com/wp/wp-content/uploads/2008/03/gnome-mime-application-x-bzip.png
 [2]: http://dor.homelinux.com/wp/wp-content/uploads/2008/03/clarke-transience.zip "Transcience, Arhtur C. Clarke"
 [3]: http://dor.homelinux.com/wp/wp-content/uploads/2008/03/clarke-the-star.zip "The Star, Arthur C. Clarke"
 [4]: javascript:void(0) "The Star, Arthur C. Clarke"
 [5]: http://dor.homelinux.com/wp/wp-content/uploads/2008/03/clarke-cradle.zip "Cradle, Arthur C. Clarke"