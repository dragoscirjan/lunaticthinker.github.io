---
title: So peaceful near you
author: dragos
type: post
date: 2012-01-11T00:23:04+00:00
url: /index.php/so-peaceful-near-you/
categories:
  - Red Wine

---
So peaceful near you, holding your red wine glass;
  
sitting so close to the edge of this eighteen floor balcony&#8230;

More peaceful than my secret inner gardens,
  
or the bossom of the wildest forest; where
  
I can always become the freedom craving beast
  
or the hunter forever in love with his pray..
  
More peaceful than
  
the calm sweet silence of a kiss&#8230;<!--more-->

E-atat de liniste alaturi de tine, tinand paharul acela de vin rosu
  
si stand sprijinita de bara celui de-al opstrezecelea balcon&#8230;

Mai liniste decat in gradinile mele secrete (imaginare);
  
mai liniste decat in sanul padurii,
  
unde  pot reveni acea fiara salbatica emanand libertate
  
sau vanatorul indragostit obsesiv de prada sa&#8230;
  
Mai liniste decat tacerea molcoma si dulce a unui sarut&#8230;