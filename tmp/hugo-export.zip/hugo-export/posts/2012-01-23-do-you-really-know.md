---
title: Do you really know?
author: dragos
type: post
date: 2012-01-22T23:45:50+00:00
url: /index.php/do-you-really-know/
categories:
  - Art of Life
  - Red Wine

---
I&#8217;m nothing but the watcher bid to see; never to touch!

I&#8217;m nothing but the child never to live nor tell his tales!
  
Not yet his time! NOT yet his time&#8230;
  
NOT YET the time&#8230;
  
There is no world where I could hide the gaze of green!
  
There is no world where I could hide&#8230;
  
You know! It terrifies me that you know; it&#8217;s not the time&#8230;
  
NOT YET the time&#8230;<!--more-->

The pages have been written still&#8230;
  
I crave the touch&#8230; I crave the kiss&#8230; I CRAVE the soul&#8230;
  
So close to the edge of your skin&#8230; so far&#8230; so far&#8230; SO FAR!
  
Forever wondering soul&#8230; Not yet the time&#8230;

Yet do you really know?