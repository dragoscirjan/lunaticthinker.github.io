---
title: Shell of a moment!
author: dragos
type: post
date: 2012-01-18T23:23:39+00:00
url: /index.php/shell-of-a-moment/
categories:
  - Red Wine

---
So we talk! Words after words flowing to the mid of night&#8230;
  
under the watch of the bitter of the Moon
  
I&#8217;m like an open book, until, each time,
  
we get to wonder the past;
  
And once again I gaze into the green&#8230;

Wish we could remain in the mid of the night,
  
shell of a moment!

<span style="color: #888888;">Si vorbim! Cuvintele curg chiar si dupa ceasurile miezului din noapte&#8230;</span><!--more-->


  
<span style="color: #888888;">Nu ne mai vegheaza decat Luna Amara&#8230;<br /> Incep sa iti par o carte deschisa, pana cand, de fiecare data<br /> ajungem sa ne minunam cat timp a trecut;<br /> iar eu ma pierd fara sa vreau in verde&#8230;</span>

<span style="color: #888888;">Am putea ramane, oare, blocati in miezul de noapte&#8230;<br /> cochilie a  unei clipe.</span>