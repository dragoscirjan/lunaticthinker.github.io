---
title: The nightmares…
author: dragos
type: post
date: 2012-01-11T12:04:37+00:00
url: /index.php/the-nightmares/
categories:
  - Red Wine

---
﻿The nightmares are back! The ones of forever changing shadows;

they&#8217;re calling me back to the sheets of lust&#8230;
  
The table of silence is back! The only words, though,
  
are the mute sounds of my lonely howls!
  
You&#8217;re nothing but a ghost!  The demon that I cannot hate;
  
Yet I will never love again.
  
You have become a ghost

<span style="color: #888888;">Au revenit cosmarurile umbrelor ce se transforma mereu;</span><!--more-->


  
<span style="color: #888888;">ademenindu-ma in profanul asternuturilor murdare&#8230;<br /> A revenit si masa tacerii; doar ca acum singurele cuvinte<br /> ce se aud in jurul ei sunt urletele mele surde.<br /> Ai devenit o fantasma&#8230; Demonul pe care nu-l pot uri;<br /> dar nu-l voi mai putea iubi niciodata.<br /> Ai devenit o fantasma..</span>