---
title: infoturism.ro
author: dragos
type: post
date: 2009-12-16T05:40:32+00:00
url: /index.php/infoturismro/
categories:
  - Uncategorized

---
A fost odata ca niciodata o eroare:

Warning: fopen(/var/www/html/www.infoturism/sql_log.sql) [function.fopen]: failed to open stream: Permission denied in /var/www/html/www.infoturism/class/pgsql.class.php on line 28

<div id="attachment_185" style="width: 310px" class="wp-caption aligncenter">
  <a href="http://35.224.157.168/wp-content/uploads/2009/12/infoturism-2.png"><img aria-describedby="caption-attachment-185" class="size-medium wp-image-185" title="infoturism-2" src="http://35.224.157.168/wp-content/uploads/2009/12/infoturism-2-300x140.png" alt="infoturism-2" width="300" height="140" /></a>
  
  <p id="caption-attachment-185" class="wp-caption-text">
    Click me for bigger view
  </p>
</div>

Am intrat pt http://hoteluri.infoturism.ro , am dat click pe Grecia, si apoi, primul link care mi-a iesit in cale (referitor la hoteluri).