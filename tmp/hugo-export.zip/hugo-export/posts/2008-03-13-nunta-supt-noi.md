---
title: Nunta supt noi…
author: dragos
type: post
date: 2008-03-13T11:58:39+00:00
url: /index.php/nunta-supt-noi/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Ne incepuseram dansul pe ritm de valuri inspumate
  
Furtuna din noi deja reflecta tragic furtunile marii&#8230;

Ce-as mai putea spune?&#8230; M-am trezit!
  
Ingenuncheat pe plaja pustie a reflectiilor surde
  
Cu mainile pline de sanfele tau clocotit&#8230;

Clocoteam si eu in clacrimi cu tepi, brazdandu-mi obrazul
  
Te pierdusem cum nici macar o pasare nu se putea pierde&#8230;
  
Printre pene plumbuite de furtuna stravezie a marii de dincolo!<!--more-->

Nunta supt noi! Cerul se coboara intinzandu-mi o mana
  
Pe tine iubito, te-am vazut in poala sa, intr-o agurida fructa&#8230;

Nunta supt noi! Valuri ma poarta, iubito, catre nicaieri pierdut,
  
Lasand in urma o dara de rosu parfumat cu a ta fiinta;
  
Sa putem gasi drumul spre inapoi, cand am sa te intalnesc&#8230;