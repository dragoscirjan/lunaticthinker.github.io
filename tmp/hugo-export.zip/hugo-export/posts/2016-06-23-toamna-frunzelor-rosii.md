---
title: Toamna frunzelor rosii
author: dragos
type: post
date: 2016-06-23T09:43:33+00:00
url: /index.php/toamna-frunzelor-rosii/
featured_image: http://lunaticthinker.me/wp-content/uploads/2016/06/WPOTWVineRedLeaves.jpg
categories:
  - Rosu

---
Ma las ei testament,
  
spre a-mi modela flacarile
  
dupa dorinta sa
  
M-am aprins iar &#8211; Stinge-ma-va
  
cu furia-i de fier&#8230;

cel mai apropiat lac
  
ar fi fost dulce binecuvantare
  
M-as fi lasat cuprins de apa &#8211;
  
mi-ar fi furat, cu sete, aerul &#8211;
  
singurul lucru care pare
  
ca imi apartine de drept.

Am lovit iar&#8230; Din carnea
  
cruda nu au iesit decat aburi
  
O eruptie era pravazuta in
  
calendarul nuferilor, iar eu &#8211;
  
pierdut prin toamna frunzelor rosii &#8211;
  
m-am aprins si eu&#8230;

<p style="text-align: right;">
  <em>2006-10-25</em>
</p>