---
title: Azi, soarele a apus pe dos
author: dragos
type: post
date: 2008-03-25T01:14:12+00:00
url: /index.php/azi-soarele-a-apus-pe-dos/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Azi, soarele a apus pe dos, iubite&#8230;
  
Si noi stateam pe dos imbratisati
  
pe cand el se stingea; iar petele negre,
  
de pe trupul tau, imi faceau foame&#8230;

Am lasat urme de bocanci, pe sanii lor, azi
  
Buzele sangerau, iar eu le sarutam
  
frenetic de fiecare data &#8211; mai mult! mai mult!
  
Eram atat de aproape sa descopar locul acela
  
in care moartea, viata, gandul si carnea<!--more-->


  
se contopesc, devenind o singura traire.

Gemenele s-au stins si ele azi&#8230;
  
&#8211; rodul unui accident &#8211; al unei aberatii
  
numita de toti cei din jurul tau &#8220;dragoste&#8221;
  
Eu nu i-am dat nume&#8230; nu le-am dat nici lor nume,
  
crezand ca sunt doar o parte din mine &#8211;
  
din gandurile mele schimonosite si rupte de noi doi&#8230;

As vrea sa iti pot spune de ce aceasta imbratisare pe dos
  
inceputa intr-un vis si terminata incinsa de pielea ta fina&#8230;
  
As vrea sa iti pot spune de ce am apus soarele intors
  
si de ce am ales ca gemenele sa se stinga.

Dar mai intai, mai musca-mi pielea o data, pana la sange
  
si soarbe&#8230; Apoi, arata-mi cum sa contopesc
  
moartea si viata, gandul si carnea&#8230; intr-o singura, unica
  
inexistenta&#8230;

2008,03,24