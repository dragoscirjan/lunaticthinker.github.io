---
title: A thief I am… I should be
author: dragos
type: post
date: 2012-01-26T23:30:45+00:00
url: /index.php/a-thief-i-am-i-should-be/
categories:
  - Red Wine

---
To meet again; to feel the bare scent of her skin
  
I&#8217;d beg today &#8211; even pretend to close my lips to &#8230;
  
I pray there be a day when I will feast
  
and feel the shivering taste;
  
her wondrous neck&#8230;

I dream to barely touch; to steal&#8230;
  
A thief I am&#8230; I should be; so call me thief &#8211;
  
for there I am, always in front of you;
  
stealing the things you would not cede<!--more-->


  
the smallest gaze &#8211;
  
the almost touch &#8211;
  
the presence!

I dare not show, nor tell again!
  
But hope&#8230; I hope&#8230; I dream&#8230;