---
title: Nouasprezece Zile
author: dragos
type: post
date: 2008-03-13T12:04:49+00:00
url: /index.php/nouasprezece-zile/
categories:
  - 'SciFi &amp; Fantasy'

---
Obosita se ridica de la masa, lasand creionul sa ii pice din mana. Parea deja prea mult pentru ziua aceea. De fapt se plictisise. Nu reusise deca sa umple doua pagini cu randuri ce nu aveau nici un sens nici macar pentru ea. Se opri in fata ferestrei, privind catre biserica a carei turla se inalta in departare, insa privirea ii trecuse deja de acel ultim varf cleric. De-ar fi putut descarca din memorie, imaginile pe care le vedea, asa cum ii apareau, ar fi fost mai mult decat perfect, insa tehnologia nu ii permitea acest lucru. Legile morale nu ii permiteau acest lucru. Era scriitoare. Trebuia sa creeze in modul traditional, cu pixul in mana si teancul de foi in fata.<!--more-->

Afara ploua torential de cateva zile. Din nou. Peste tot in lume, se anuntau din ce in ce mai multe inundatii. Cotele crescusera alarmant de mult. Aproape toate raurile isi iesisera din matca si in aceasta zona, iar specialistii estimau ploi continue pe o perioada nelimitata. Totul parea a fi o razbunare a naturii impotriva a tot ceea ce oamenii au facut, de-a lungul timpului, impotriva ei. Autoritatile erau la fel de speriate ca si intreg poporul. Complet neputincioase. Toate incercarile lor de a stapani inundatiile fusesera zadarnice. Cu toate acestea, oamenii isi continuau rutina de zi cu zi, nevoiti sa isi duca traiul mai departe. Nimic nu mai parea a uimi omenirea, de cand calotele glaciare se topisera fara avertisment. O mare parte din continente fusesera inghitite de ape, si totusi continua sa ploua.

*Si Dumnezeu a spus:
  
&#8211; Noe, contruieste arca. E timpul ca toti cei ce nu asculta sa fie pedepsiti.Era vechi planul acesta gandit de Dumnezeu la sfatul celui numit Noe. Credinciosul Noe s-a apucat sa construiasca o arca. Atat de mare incat puteau incapea in ea mii de oameni, alaturi de toate speciile pamantului. Toti cei din ea trebuiau sa supravietuiasca potopului ce avea sa vina. Dumnezeu nu a zis nimic. Probabil ca i-a placut, sau probabil ca uitase pana si sa urmareasca inceputul Potopului la cat de ocupat era in a crea partea sa din acest proiect distructiv.

*Nu! Nu era bine. Era o mare prostie sa dezvolte acea poveste. Se ridica iar de la birou, nervoasa si aruncand creionul pana in coltul opus al camerei. Se opri insa doi pasi mai incolo. Da. Asta era&#8230; asa ceva ar fi scris si el. Trebuia sa o faca. Trebuia sa il socheze in vreun fel. Cu siguranta Nio nu s-ar fi asteptat la asa ceva din partea ei. Nici ea nu putea fi atat de imprevizibila cand venea vorba de ceva scris. Se aseza din nou in fata colii de hartie, luand un alt creion in mana, insa realiza ca e timpul ca el sa ajunga acasa. Lua foaia cea nou inceputa si o ascunse in sertar tocmai cand in broasca usii de la intrare se auzi cheia lui. Ajunsese acasa.Se ridica si ii iesi in intampinare. Noe tocmai intra pe usa, cu servieta in mana stanga si luandu-si palaria de pe cap cu dreapta. “Bun venit, iubitule.” “Bine te-am gasit, Naama.” “Cum a fost?” “Greu. Dar cred ca l-am convins. Proiectul va fi aprobat in curand.” Il imbratisa dragastos ca intotdeauna, iar apoi il conduse in bucatarie. Masa era pregatita deja. Asezati in cate un capat al mesei, se priveau unul pe altul cu drag. “Ai reusit sa scrii ceva?” “Nu. Sunt foarte dezamagita de mine in ultima vreme.” “De ce?” “Nu pot scrie nimic cum trebuie. Azi, spre exemplu, m-am invartit intre cateva randuri mazgalite pe vreo doua pagini. Nu a iesit nimic bine.” Nio se ridica de la masa si apropiindu-se de Naama, se apleca incercand sa ii prinda caute privirea cu a sa. “Pot sa vad?” Naama ofta. “De ce nu&#8230;”

”Frumoasa incercare, dar ma astept la mai mult din partea ta.” Naama zambi. Stia ce ascundea in sertarul biroului iar lucrul acesta o facea sa treaca peste dezamagirea lui. Aproape ca il vedea citind lucrul acela si, intr-un final, uimit de sfarsitul povestii, ridicand privirea si zambindu-i uimit de ideea femeii. Gandul acesta parea sa incline un pic balanta catre ungherul plin de caldura din sufletul femeii. Celelalte ganduri erau pline de durere. Plecarea fusese aprobata&#8230; Era inevitabil acum.

*A venit si timpul potopului, iar Noe si-a strans fii si a urcat pe arca alaturi de toate vietuitoarele pamantului si de mii de alti oameni pe care el i-a considerat vrednici de a supravietui Potopului. Apele crestcusera zi de zi, iar ploile nu contenisera nici in a nouasprezecea luna. Noe si ceilalti se izolasera in arca cand apa a ajuns pe nesimtite la ei. Si totusi nu era in firea oamenilor sa astepte. Nu era in firea omului sa stea linistit. El avea nevoie de spatii in care sa se desfasoare, sa construiasca sau sa creeze. Nu un loc atat de mic precum arca aceea.Nu stiau cat de mult avea sa tina potopul si nici cat va trece pana ce apele au sa se retraga, iar Dumnezeu parea ca ii uitase. A trecut mult timp pana ce Acesta si-a intors iarasi fata spre Noe, insa era nemultumit de ceea ce slujitorul sau facuse.

&#8211; Noe, Eu am cerut sa fie pe arca ta numai din cei ce stiu sa asculte.
  
&#8211; Doamne, am facut si eu ce am putut.
  
&#8211; Cum asa, Noe. Nu te-am invatat Eu?
  
&#8211; Sunt om, Parinte, nu am intelepciunea Ta.

Dumnezeu a ras aprobator.

&#8211; Asa e, Noe. Dar credeam ca ma cunosti mai bine decat atat.
  
&#8211; Atunci cand iubeste vitata, omul greseste cel mai mult, Doamne.

*- Ce faci, Naama? Scrii? Prea bine iubito, te las sa termini. Eu ma duc sa ma culc. Sunt prea obosit azi.Parea inbufnat? Oare ce il suparase la docuri? Se ridica de la masa si porni pe scari catre dormitor, unde isi gasi sotul intins in pat. Se aseza langa el obosita si trista. Il simtea rece si distant, iar lucrul acesta se inampla doar cand venea suparat de pe santier. Stia ca sufera din cine stie ce prostie si suferea alaturi de el.

Amanasera lansarea vasului cu inca doua luni pe motiv ca mai aveau niste lucruri de finistat. Puricasera fiecare detaliu la acel vas de atata timp. Avea sa fie perfect, o stia, iar el avea sa fie cel ce il va fi dus pentru prima data in larg. Si cu toate acestea, cu toate ca asistase timp ce trei ani la constructia propriei sale nave, dupa planurile create de propria echipa de ingineri, acum trebuia sa astepte. El nu putea astepta. Era omul cel mai nerabdator de pe pamand, iar Naama stia lucrul acesta. Asteptase destul trei ani de zile pana cand vazul fusese construit. Trei ani de zile in care aproape uitase cum era acolo, in spatiul acela larg si plin de necunoscut de fiecare data cand il explora. De data aceasta un vas de explorare. O nava ce avea sa il duca la limitele lumii cunoscute, sa faca cercetari si sa se intoarca inapoi cu raspunsuri si, mai ales, cu solutii.

*Dumnezeu i-a cerut sa renunte la oameni, iar Noe nu a dorit a renunta.- Si atunci pentru ce am facut toate astea, Noe? Pentru ce potoptul acesta, ce a ucis atatea miliarde de oameni? Noe? Noe!
  
&#8211; Da, Doamne.
  
&#8211; De ce taci, Noe?
  
&#8211; Incerc sa dau un raspuns. Caut unul pe care sa il putem accepta amandoi.
  
&#8211; Eu in postura de Zeu si tu in postura de Om, Noe? Sau in postura de inger servind mie?
  
&#8211; In postura de om, Doamne. Ingerul ce l-ai pedepsit a fi om, pentru neascultarea Ta, acum tanjeste a ramane om.

Dumnezeu a tacut o vreme apoi. Noe a presupus, ca pentru o vreme El nu ii va mai cere sa renunte si la acea parte din oamenii pe care ii salvase. Si ce daca nu stiau sa asculte? Erau deja o entitate independenta de Dumnezeu. Stiau deja sa traiasca si fara ajutorul Divinitatii. Oare asta Il mania atat de tare? Probabil si el, Noe, s-ar fi simtit maniat, daca tot mai multi dintre discipolii sai l-ar uita.

*Naama fu trezita de videoefon in miez de noapte. Il cautau pe Nio. Nava era in sfarsit gata de lansare. Reusisera sa treaca in sfarsit de birocratii ce ii impiedicasera pana atunci mai mult decat reusisera sa impiedice desfasurarea fortelor naturii. Toate cele trei mari confederatii ce participasera la proiectul Merlin III ajunsesera la o intelegere privind ceea ce aveau sa obtina de pe urma acelei expeditii. Un zambet imens se nascuse pe pe fata barbatului, insa disparu imediat ce intalnii privirea Naamei. Ea avea sa ramana pe Pamant.Bagajul fu facut, fara ca vreunul din ei sa vorbeasca. Poate ca, intr-adevar nu mai era nimic de spus. Subiectul fusese atat de discutat incat orice intoarcere la el ar fi provocat prea multa durere pentru amandoi. Renuntasera de mult a-l mai discuta. Tacerea incepuse sa devina apasatoare cand bagajul paru a fi aproape gata. Cu lacrimi in ochi, femeia lua ultima camasa a barbatului, o impaturi si o aseza in geamantan. Gata. Totul era asezat. geamantanul inchis si dus pana la usa, zambetul fiecaruia zavorat dupa usi groase, ce pareau a nu se mai deschide curand. Va lipsi mult timp. Nici el nu stia cat va lipsi, si mai ales, daca se vor mai intoarce. Acela avea sa fie destinul lor.

*Naia il privea ingrijorata pe barbatul sau, care tocmai scapase o injuratura la adresa Divinitatii.- Ce e cu tine, Noe? Tu sa faci asa ceva impotriva Domnului?
  
&#8211; Vantul a incetat sa bata, Naia. Marea se schimba iar. Catargul dintre cele doua avamposturi s-a rupt.
  
&#8211; Ce catarg, Noe? Ce avamposturi?
  
&#8211; Ratacim pe cai aliniate de-a lungul unor stele, al caror drum nu pare a fi niciodata intreg. Se frange mereu. S-a rupt doua rindele in urma, iar acum se frange sub noi fara sa ne dam seama.
  
&#8211; Noe, dragul meu, esti bine? Ce tot spui acolo.

Barbatul o privi nedumerit. Nu isi aducea aminte sa fi spus ceva. Ii facu semn ca da si ca poate pleca, iar apoi se intoarse din nou cu fata catre manuscriptul din fata sa.

Vantul a incetat sa bata. Marea se schimba. Catargul dintre cele doua avamposturi s-a rupt. Ratacim pe cai aliniate de-a lungul stelelor, insa drumul nu pare a fi niciodata intreg. Se frange. S-a rupt doua rindele in urma, iar acum se frange sub noi. Cu mainile ridicate spre cer ne agatam de scarile ce coboara din nori de vata de zahar. Nu inteleg de ce am ajuns sa urcam, insa acum mancam din ei cu foame. E o foame nascuta din interiorul mintii noastre si pare a nu se satura. Incep sa moara. Acum stiu.

Am descoperit in sfarsit versetul ce stapaneste aceasta lume. Blestemul acesta il foloseam si noi cand am construit Babilonul. Ploua cu datini&#8230; Vorbim toti la fel?

Ne-am otravit de unii singuri, fara a da crezare propriilor credinte. Foamea ne-a ucis pe rand! Cu o ultima sfortare am taiat si celelalte catarge, facand o pluta. Incercam sa ne salvam? Ne avantam in necunoscut. Incercam sa&#8230; Ridicati panzele. Vantul bate spre nord! Si pornim. Drumul e curat&#8230; Are sa fie curat pentru o vreme.

*- Capitane, e timpul.Nio, intoarse capul spre el si aproba din priviri. Se aseza la locul sau pe puntea de comanda si dadu semnalul pentru iesirea din docuri.

&#8211; Cu Dumnezeu inainte&#8230; Fie sa fim aparati de maretia si intelepciunea Sa.

Stia ca nu era un lucru prea intelept sa vorbeasca despre Dumnezeu la bordul navei, insa acele cuvinte nu si le putu stapani. Oamenii ii cunosteau ingrijorarea. Cu multi dintre ei lucrase la proiectarea si constructia navei, multi il cunosteau mai bine decat, poate, pana si prietenii sai cei mai apropiati. Erau, de fapt, un fel de a doua familie pentru el. Da. Asta erau. Spera ca cei de alte religii l-au inteles, si privi in tacere cum nava se deplasa catre iesirea din statia orbitala, cu destiantia&#8230; „Acolo undeva&#8230;”

Scopul declarat al acelei expeditii era sa gaseasca un nou Pamant.

*- Noe, am hotarat asupra oamenilor tai.
  
&#8211; Te ascult, Domnul meu.
  
&#8211; Te vei despartii de ei, Noe. Daca vor reusi sa supravietuiasca timp de 19 ani, in deriva, atunci vor trai mai departe fericiti si fara de prea multe griji. Daca nu, regatul Meu e indeajuns de incapator si pentru ei.
  
&#8211; Doamne, nu esti prea dur cu ei?
  
&#8211; Si asta a fost ideea ta, iti aduci aminte, Noe?Noe tacu. Ce putea spune?

*- La revedere, Nio. Dumnezeu fie cu tine, iubitul meu.
  
&#8211; La revedere, iubito.O ultima intersectare a privirilor, apoi Nio pleca pe usa ce ducea catre naveta de imbarcare. Toata caldura cu care isi trata sotia acasa avea sa dispara, inlocuita cu raceala si calmul pe care trebuia sa le afiseze fata de subordonatii sai.

&#8211; Buna ziua, Nio.
  
&#8211; Letah&#8230;

Nio zambi intampinat fiind de bunul si batranul sau prieten si secund. Letah ii intinse mana, iar Nio o stranse cu incredere. Porni spre puntea de comanda, urmat de secund si de ofiterul desemnat sa il insoteasca pana la nava. Plecau, si zece miliarde de oameni ramaneau in urma cuceriti de agonia temerilor, insa cu speranta da a afla curand o lume noua pentru ei. Cel putin lucrul acela le fusese promis.

*Aproape ca a implorat&#8230; Era divin sa il vezi pe Noe cum cade in pacat pret de cateva clipe! Aproape ca a implorat atunci cand Dumnezeu s-a apucat sa ucida pe cei fara puterea de a asculta. A tacut o vreme. Cazuse cerul iar. Norii se curmasera asupra sa, iar ingerii sai mureau randuri randuri, la picioarele sale. Noe&#8230; El se gandea ca a ramas un numar simetric de zile&#8230; Si numarul acela scadea&#8230;- Doamne!
  
&#8211; Da, Noe.
  
&#8211; De ce atata durere pe Pamantul acesta?

*- Cine sunteti si ce cautati in sistemul acesta?
  
&#8211; Sunt Nio, capitan pe Merlin III, nava de explorare. Planeta noastra e moarta. Cautam un nou camin pentru noi si cei de acasa.

*- Noe!
  
&#8211; Noe!
  
&#8211; Cine ma striga?
  
&#8211; Noe, suntem noi, Naia si fiii tai!
  
&#8211; Nu am nici un fiu! Nu va cunosc! Plecati! Plecati!
  
&#8211; Noe, suntem familia ta. Deschide usa, sotul meu!
  
&#8211; Plecati! Nu va mai cunosc! Plecati!Noe se ferecase intr-o camara a barcii de cateva luni de zile. Nimeni nu stia ce facea protectorul lor, singur in acea camara. Parea ca ar construi ceva, insa nimeni nu reusise sa afle ce. Intr-un final, fii sai au hotarat sa darame usa camarii, insa nu a fost nevoie caci Noe a deschis singur usa. Toti s-au dat in laturi, speriati de infatisarea parintelui lor, insa acesta aproape ca nici nu i-a mai recunoscut. A trecut printre ei si a urcat scarile catre punte.

&#8211; Doamne! Ai vrut ca ei sa dispara. Eu nu vreau asta!
  
&#8211; Noe? Oamenii nu mai stiu sa asculte, Noe.
  
&#8211; Oamenii nu mai au nevoie de noi, Doamne!

*Dulce iubita. Ma aflu la zeci de milioane de ani lumina, intr-o galaxie numita, de catre localnicii, Narilium. Noi, pe Pamant, o numeam Cancer sau Scorpion. Nu e bine deloc iubito. Am nimerit in mijlocul unui razboi al carui sens nu il inteleg, si in acelasi timp, am descoperit ca sunt singurul care il poate opri. Incotro ne indreapta destinul si cat de ironic poate fi cu noi, uneori. Sunt la curent cu starea de pe Pamant. Am aflat ca se pregatesc inca doua nave ce vor pleca spre Sagetator si catre Rac. Capitanul de pe Merlin IV este un foarte bun prieten al meu, si l-am convins sa te ia cu el in postura de consilier in privinta vietii extraterestre. Vor pleca spre Sagetator in mai putin de un an. Ce om poate fi mai bun in acest post de consilier, decat un doctorand in psihologie, scriitor de S.F.?Iti citesc povestea, iubito. Aici nu exista Dumnezeu. Aici nu exista zei, sau fiinte adorate. Ma face sa ma intreb daca noi acasa am facut bine crezand intr-o existenta superioara noua. Si totusi, daca nu am crede, cum am putea explica ceea ce se intampla pe Pamant, acum? Continua sa scrii, iubito. Am sa iti scriu, din nou, curand.

&#8211; Nebva, trimite scrisoarea in format audio, alaturi de datele despre proiectul Merlin IV catre Naama Noks pe adresa mea de acasa.

Computerul executa comanda, apoi reafisa display-ul de asteptare, in timp ce Nio iesi din cabina sa indreptandu-se catre puntea navei.

&#8211; Letah, Noria, am luat decizia ca Merlin III va va ajuta in razboiul impotriva simbiotilor. Exista insa si cateva conditii, regina Noria.
  
&#8211; Oricare ar fi acelea, tanar conducator, le voi indeplini cu buna credinta.

Nio zambi. Poate ca mai aveau o sansa.

*Realizase ca timpul nu avea sa il lase niciodata sa scape din ghearele sale. In reflexia sa euforica, Noe statea cu fata spre rasarit, privind spre scapararea din celalalt sine. Acolo inca era o lumina&#8230; &#8220;Au mai ramas sapte!&#8221; isi spuse, si apoi isi intoarse privirea spre nori. Sapte randuri de aripi se coborau catre el, iar umbrele lor erau de foc. Cu un ultim sarut, furat violet, Noe isi desfacu si el aripile cele noi, luandu-si zborul. Privea cum cei sapte aprindeau pamantul in calea sa. Foc de un violet mut&#8230;

*- Nu deschideti focul pana nu ajungem in centrul lor! Repet, nu deschideti focul pana nu ajungem in raza de detonare!
  
&#8211; Scuturile din sectoarele A si F aproape ca au cedat, capitane!
  
&#8211; Treceti-le pe sistem auxiliar! Letah, subsistemul trei!
  
&#8211; Da capitane.
  
&#8211; Ramai la conducere.
  
&#8211; Capitanul iese de pe punte!De data aceasta insa, nimeni nu schitase nici un salut. Nio iesise in fuga de pe puntea de comanda, indreptandu-se spre una din navetele de lupta.

&#8211; Regina Noria, daca doresti sa lupti, acum este timpul. Merlin si rebelii lupta chiar in acest moment cu asupritorii tai. Adunati oamenii, regina! Lupta! Fa din Narilion un popor liber!

Noria il privea tematoare. Poporul al carei regina devenise cu milenii in urma incetase a fi unul razboinic cu ere inainte de venirea asupritorilor.

*Linistea il zavorase intr-un final&#8230; Ramasese doar el. Unul singur in tot Raiul si unul profet isi era numai lui. Focurile se stinsesera de mult, iar sarutul violet il uitase intr-o clipa, cucerit de propria-i viziune. Singuratatea era la un pas de a se indragosti de fiinta lui de ceata.Pierdut de sine, Noe plangea. Intors inapoi, pe arca sa cea pustie, implora pentru o minune. Aceea de a crea lumea dintr-un fir de sine, caci totul dinaintea luptei cu Dumnezeu se pierduse.

Cerul nu a stiut sa ii raspunda decat printr-un cantec vechi si uitat &#8211; viorile din Chi Mai&#8230; A fost secolul in care Noe a aruncat blestemul asupra numarului sase.

Iar el incepuse sa se nasca.

*Dulce iubita,
  
ma aflu in mijlocul unui razboi pe care nu il inteleg. Am inteles ca ai acceptat postul de pe Merlin IV. Iti multumesc, iubito. E greu sa te stiu departe, dar gandul ca te stiu departe de planeta aceea aproape moarta ma face sa ma simt mai bine cu toate ca am schimbat un pericol cu altul. Poate ca pericolul acesta e mai mic. Cum te simti? Am primit ultimile fragmente din povestea ta. Nu inteleg unde bati, iubito. Iti inteleg furia, dar&#8230;Stau si ma intreb cine sunt. Stau si ma intreb de ce Dumnezeu m-a ales pe mine sa nimeresc in mijlocul acestui razboi. Oare acesta e modul Lui de a ma pedepsi pentru ca am incercat sa imi salvez semenii? Oare salvand aceste fiinte, capat dreptul de a-i ajuta pe cei de acasa? Ce pret poate plati un om pentru a salva ceea ce iubeste mai mult?

Inca nu am primit nici un raport de pe Merlin IV. Am inteles ca oamenii de stiinta de acasa au descoperit doua planete ce satisfac conditile de dezvoltare a vietii in Sagetator. Aici am descoperit viata, dar si durere. Multa durere. Poate voi veti avea mai mult noroc. Scrie-mi, te rog. Eu raman ingropat in acest razboi, in care azi am castigat prima victorie, poate.

&#8211; Ce este cantecul acesta, straine Nio?
  
&#8211; Cantecul viorilor din Chi Mai, regina. Un loc de acasa. E cantecul preferat al sotiei mele. Din pacate in lumea mea acel loc nu mai exista. A fost inundat de ape.
  
&#8211; Inteleg, straine Nio. Iti este dor de ea&#8230;

Omul ii arunca o privire inexpresive, de soldat, apoi comanda trimiterea scrisorii. Se intreba de cat timp era regina prezenta in camera aceea. Incerca sa isi limpezeasca mintea, sa isi alunge gandurile despre cei de acasa. Trebuia sa termine ceea ce incepuse acolo.

&#8211; Sa mergem, regina. E timpul sa ne infatisam consiliului.

*- Cat timp, vom mai suporta asuprirea lui Noe? Doamne, cat timp va trebui sa ne ascundem de acest monstru?

*Trecusera nouasprezece ani de la prima sa plecare de pe Pamant. In cele trei calatorii ale navei sale intre Terra si stelele din Narilium reusise sa salveze cateva sute de mii de oameni. Inca cinci nave spatiale fusesera construite in timpul acesta, si toate faceau eforturi disperate de a transporta cat mai multi oameni catre Scorpion si Sagetator. De nouasprezece ani de zile nu isi mai vazuse sotia, insa o stia in siguranta.Fusesera construite opt nave pana cand Pamantul fusese acoperit total de ape. Un ultim bastion, construit aproape de varful Everestului, fusese acoperit de ape cu un an in urma. Nimeni. Absolut nimeni nu reusise sa inteleaga de unde acea abundenta de ploi. Nimic de pe acea planeta nu putea crea atata apa. Nici o explicatie stiintifica.

Urmau sa faca ultimile doua calatorii. El si Merlin IV urmau sa transporte ultimile doua sute cincizeci de mii de oameni, de pe statia orbitala Nur catre cele doua galaxii catre care acestia pornisera. Aveau sa ajunga pe Nur in acelasi timp. Avea sa isi intalneasca, in sfarsit, sotia. Dupa nouasprezece ani avea sa o revada pe Naama.

*- Cine indrazneste sa imi framante linistea?
  
&#8211; Noe! Ucenicul pierdut.Noria se ridicase din tronul sau, privind cu interes batranul din fata sa.

&#8211; Nu am mai auzit de mult numele acesta. Vino! E timpul sa iti vezi regatul!
  
&#8211; Nu pentru asta am strabatut Narilium pana aici, paznicule!

Noria il privi contrariata. Bucuria regasirii ucenicului rege pieri cand ochii celor doi se intalnira.

&#8211; Ai venit pentru mine&#8230;
  
&#8211; Si pentru linistea cerurilor, paznicule! Cele cinci pietre, te rog!

*- Capitane, Nio. Intra in birou, batrane. Ia loc.Noe il asculta pe prietenul sau, asezandu-se pe fotoliul din fata acestuia.

&#8211; Ce este Letah, prietene? Ce s-a inamplat?
  
&#8211; Vor sa te puna dupa gratii, Nio. Am aflat la doua zile dupa ce ai plecat in ultima misiune.
  
&#8211; Sub ce motiv.
  
&#8211; Tradarea misiunii la inceputul sau. Spun ca din cauza ta au murit milioane de oameni pe care ii puteau salva. Spun ca implicarea ta intr-un razboi care nu ne privea a dus la intarzierea misiunii tale.
  
&#8211; Pe scurt au nevoie de un tap ispasitor care sa fie raspunzator in fata celor salvati. Idioti imputiti! Astia nu isi dau seama ca oamenii aia sunt alaturi de mine acum? Le-am gasit o casa noua, pentru Dumnezeu.

Nio se ridica de la masa furios, vrand sa iasa din acel birou insa se opri in fata usii. Momentul de tacere se prelungea din ce in ce mai mult, pana cand&#8230;

&#8211; Probabil ca asa as face si eu.
  
&#8211; Omule, ce tot bombani acolo?
  
&#8211; Poate ca au dreptate, Letah&#8230; Am intarziat acolo unde trebuia sa ma grabesc! Milioane de oameni contau pe ajutorul meu.
  
&#8211; Ai salvat mai bine de doua miliarde de oameni, omule! Ai facut tot ce ai putut! Cine stie cat de mult am mai fi cautat, daca nu incheiai acea alianta!

Omul se intoarse catre prietenul sau cel mai bun. Privirea neputincioasa se accentuase. Parea ca nu mai stie unde se afla si in acelasi timp, in mintea sa rasuna un singur nume. Cel al sotiei sale.

*&#8221;Parca nu mai era imbratisare contopirea aceea din urma, cand c adevarat se topeau contururile, disparea carnea, ne uitam respiratia, contopiti amandoi de o singura &#8211; insangerata si nesatioasa gura. De multe ori am nadajduit ca la capatul rapirii aceleia vom intalni, impreuna moartea. N-am stiut ca poate fi atat de ispititoare, atat de calda &#8211; voluptate fara spasm, beatitudine fara strigare&#8230;&#8221;
  
(Mircea Eliade &#8211; Nunta in cer)Citind aceste randuri ei ii aparu in minte cea mai puternica idee de pana atunci. Revelatia de care avea nevoie. Moartea!&#8230;

Lasand cartea, pe nisip, langa ea, Noria privi catre zare. Cei sapte, blestemati acum a trai vesnic in pasari marine, zburau catre zari. Probabil era ultima lor sfortare de a se elibera de blestemul cumplit pe care Noe il adusese asupra lor.

Intr-adevar&#8230; daca ei faceau lucrul acesta, ea de ce sa nu se elibereze astfel?

&#8220;Adio tuturor celor ce ai fost, Noria&#8230;&#8221;

*In cabina capitanului, pe Merlin III, computerul afisa un ultim fragment dintr-un text al carui inteles il cunostea numai Nio. Era a doua oara cand sotia sa mentiona acel nume in povestirea sa, fara sa fi stiut, in vremea aceea, ce semnificatie avea acel nume. Se intreba cum de reusise sotia sa, a descoperi numele acesta, mai ales ca nu era nume pamantean. Cum reactionase oare, mai tarziu, cand probabil aflase ca de regina Noria, din Narilium depindeau vietile a miliarde de oameni?Capitanul Nio este facut vinovat de neglijarea misiunii sale. Asupra acestei acuzatii, juriul a deliberat timp de doua saptamani, iar acuzatul a fost gasit vinovat. Capitanul va sta sub arest in cabina sa de pe Merlin III pana cand va fi hotarata sentinta. Capitanul Nio nu are voie sa paraseasca Merlin III sub nici o forma.

Inca ii mai rasunau in urechi cuvintele sefului consiliului guvernator de pe Håp, planeta pe care Noria o daruise capitanului Nio spre a o popula cu oamenii salvati de pe Terra. Stia ca se va ajunge aici. Stia de cand plecase ca prin atitudinea sa cat se poate de agresiva calcase pe coada multe personalitati politice, insa pe vremea aceea toti il vedeau ca pe un salvator. Proiectase cea mai puternica nava din ultimi doua sute de ani de la prima nava spatiala ce ajunsese in spatiu si in plus, era descoperitorul unei surse de energie extrem de puternice – materia exotica. Nimeni nu reusise sa o stapaneasca inaintea sa.

Acum insa, dupa nouasprezece ani de la prima lansare a lui Merlin III, cu toate ca multi il consierau un erou si aproape un sfant pentru ca reusise sa salveze aproape doua miliarde de oameni, foarte multe guri rele reusisera sa il sape.

*Si porumbelul se intoarse aducand in cioc ultima ramura a existentei sale. Era timpul sa se intoarca in nefiinta, alaturi de dragostea sa cea mai puternica &#8211; singuratatea.Noe era pierdut. Nimic nu l-ar mai fi putut aduce inapoi, iar vestea trecerii ei in nefiinta nu il ajunsese din urma. Noe trecuse in pacat&#8230; Noe era pacatul acum&#8230; iar ea singurul inger in viata&#8230; Blestemat sa il astepte pentru a se sfarsi immpreuna.

*Dulce iubita,
  
ma pregatesc sa fug spre Sagetator, cu toate ca sunt absolut sigur ca si acolo se va intampla acelasi lucru. Cu toate ca ai terminat povestea aceea de cativa ani de zile, continuu sa o citesc de fiecare data cand imi e dor de tine. Nici nu iti poti inchipui cat de uimitor a putut fi pentru mine sa faci anumite legaturi fara macar sa stii despre ce e vorba. Mai ales una&#8230; un nume, iubito. Un nume&#8230; Un nume pe care l-ai gandit fara macar sa stii despre ce era vorba. <&#8230;> Spune-mi te rog daca acest nume are legatura cu ceea ce ti-am povestit.Acum inteleg intr-adevar despre ce e povestea ta, iubito. Cel ce iubeste, pierde intotdeauna tot ceea ce a iubit. Din dorinta de a salva ceea ce iubeste mai mult, Noe se razvrateste si in acelasi timp cade in pacat. Lupa lui nu e una pe termen scurt, ci una seculara. Singurul lucru care il mai leaga de timpul in care a inceput lupa e arca. Arca pe care o paraseste si care in timp devine un loc pustiu si lipsit de viata. Nu conteaza daca oamenii au murit sau au plecat. In lupta sa, Noe nu stie sa priveasca inapoi, e uitat si parasit. Nu conteaza cum.

Tentatia suprema este aceea de a crea de unul singur. Insa acesta este pacatul suprem. Pacatul care il subjuga. Singuratatea si imposibilitatea de a crea. Noria reprezinta un fel de speranta. Atat. In timp speranta moare si odata cu ea si el&#8230;

Vin, iubito. Plec din aceasta lume pe care am ajuns sa o indragesc atat de mult. Plec spre tine. Si am sa iti spun in sfarsit povestea acestor nouasprezece ani petrecuti departe de tine.

Se ridica de la masa, intorcandu-se cu spatele si indreptandu-se spre usa cabinei, dar nu iesi inainte de a da comanda de expediere a scrisorii.

&#8211; Comanda eronata.

Se opri in fata usii, cu mana intinsa catre butonul de deschidere a usii.

&#8211; Nebva, explica-te.
  
&#8211; Nava Merlin IV nu a mai fost detectata de la plecarea dumneavoastra de pe statia spatiala de pe Terra.

Il trecu un fior rece, inghitind in sec. Imposibil. Merlin IV ramasese inca cea mai sigura dintre cele opt nave construite. O proiectase cu mana lui, inainte se place de pe Terra. Nu putea disparea atat de usor.

&#8211; Nebva, cheama-l pe comandorul Letah in cabina mea.

*Era aproape de sfarsit&#8230; Ceea ce ramasese din Noria, in inchisorile singuratii, era aproape imperceptibil. Singuratatea, singura ei dragoste, reusise sa roada pana si cea mai mica prezenta a ei. Disparuse. Noe pierduse batalia cu cerurile.Izgonit, in lumea de apoi, transformat in cea mai hada fiinta, era pazit pentru a nu se razvrati de unul dintre cei mai puternici intelepti ai timpurilor. Intunericul incepuse deja sa ii orbeasca gandurile. Murea&#8230;

*- E adevarat Nio.
  
&#8211; Cand ati aflat?Omul tremura din toate incheieturile.

In momentul acela, o lumina extrem de puternica navali pe hubloul cabinei, urmata de o bubuitura puternica ce capta atentia amandorura, inmarmurindu-i.

&#8211; Narilion!
  
&#8211; E un vierme. Un distrugator de planete.
  
&#8211; Nebva! Raporteaza!
  
&#8211; Un nucleu vierme a fost detonat pe Narilion. Coordonatele exploziei indica faptul ca aceasta a avut loc chiar in capitala planetei. Planeta este insa prea mare pentru a fi afectata de dimensiunile acelui nucleu.
  
&#8211; Noria&#8230;
  
&#8211; Consiliul!
  
&#8211; Si-au atins scopul, Letah. Ne pregatim de razboi, prietene. Din nou&#8230; De data asta se pare ca suntem singurii care putem salva coltul asta de univers de intuneric.

*- Domnul meu&#8230; Parinte&#8230;
  
&#8211; Ce este, Déchirure?
  
&#8211; Parintele meu, Noe a evadat&#8230;- Voi trimite alti ingeri! Demonul trebuie prins!
  
&#8211; Iarta-ma, Parintele meu&#8230; Am gresit.
  
&#8211; Nu, Déchirure, nu este vina ta. Noe este cel mai puternic razvratit impotriva mea de pana acum&#8230;

In urma lui, umbrele incepeau sa cucereasca intregul plan existential. Ingerii se temeau sa plece dupa el, iar Dumnezeu incepuse sa realizeze ca nu il mai putea stapani pe Noe&#8230; Nu mai exista timp! Demonul se nascuse, si mai era doar o zi pana sa isi arate adevarata putere. Ziua a saptea.

*- Letah, eu plec spre Terra.
  
&#8211; Prietene, avem mare nevoie de tine aici.
  
&#8211; Trei nave de lupta vor sosi dinspre Sagetator in maxim doua saptamani. Ii veti invinge, Letah. Ma roade, prietene. Trebuie sa stiu.
  
&#8211; Putem contacta Nur de aici.
  
&#8211; Am facut asta deja. Observatorii de acolo nu mi-au putut da prea multe informatii. Plec, Letah. Vreau macar sa isi aiba un loc de odihna. Stiu ca ma intelegi. Deindata ce Horus II ajunge aici am plecat. E nava specializata pentru lupta. Va va fi de mult mai mult ajutor decat batranul merlin.Comandorul privea ganditor catre harta stelara de pe panoul de control.

&#8211; Ai grija sa te intorci prietene. Nu am terminat inca.
  
&#8211; Imi iau nava si trei oameni cu mine. Am sa ma intorc batrane, am sa ma intorc. Promit lucrul acesta.

*L-a gasit, intr-un final. Lasase in drumul sau o urma imposibil de pierdut. Toti ce plecasera in cautarea sa, nu se mai intorsesera, asa ca Dumnezeu s-a hotarat sa il caute el insusi.Inconjurat de trupurile a mii, ucisi, statea ingenuncheat in fata unui mormant.

&#8211; Iubito, m-am intors&#8230; Sunt chiar eu, iubitul tau&#8230; Iubito, m-am intors&#8230;

Ochii ii sticleau, iar gandurile se pierdeau in tacere&#8230;