---
title: Masa tacerii
author: dragos
type: post
date: 2008-03-13T11:59:51+00:00
url: /index.php/masa-tacerii/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
E întuneric alaturi de formele acestea colturoase de stejar tacut
  
Într-un candelabru batrân, de alama-negrita
  
si-au început viata acum un mileniu si jumate
  
doua lumânari reci, arzând o noua vesnicie muta&#8230;

Timpul trece! Sub formele sale, trecând plapânde si adormite,
  
ale noastre par sa se schimbe cu fiece nesfârsita clipa
  
careia noi nu am stiut sa îi cerem sa ne ramâna&#8230;

Sub streasina ochilor tai se strâng siroaiele ploii;<!--more-->


  
e singurul cântec gingas tacerii acesteia de piatra!

Nemaiîntelegând ploaia aceasta, ma ridic si urlu la tine scurt:
  
&#8220;De ce?&#8221; Nu astept&#8230; un raspuns&#8230; nu are sa vina niciodata&#8230;

În linistea de mormânt dintre noi, timpul a devenit subit
  
a treia persoana la masa rotunda a tacerii&#8230;
  
Ne luptam în tacere caci sabiile ni le-am rupt amândoi demult,
  
cand am ucis farâmele de cuvinte si furiile coborâte cascade!

Îti simt mâiniile înfipte în gâtul meu, cu dorinta nestapânita de a strânge &#8211;
  
te las; Te las caci nu am putut lupta niciodata,
  
Dar tu în schimb te arunci la gura mea spre sarutul otravitor &#8211;
  
ni-l dam unul altuia cu foame, ca apoi sa reluam masa tacerii&#8230;

Îti simt mâna curgând pe chipul meu, precum o boare de vânt dimineata
  
Niciodata vocea&#8230; vocea a ramas undeva în fundal
  
când am început sa ne curgem trupurile spre linistea aceasta absurda&#8230;
  
Doi pioni în linistea neschimbata a unui univers
  
pe care nimeni dintre cei vii, cu adevarat, nu stiu sa-l asculte&#8230;