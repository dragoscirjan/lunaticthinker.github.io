---
title: Ploi verzi
author: dragos
type: post
date: 2008-03-13T11:58:12+00:00
url: /index.php/ploi-verzi/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Pe mal inspumat de albastru candid
  
Scoici mi-au ramas sfaramate supt
  
picuri stravezii din taplile-mi insangerate

Azi unde esti? Maine unde sunt&#8230; &#8211;
  
un joc de a fi&#8230; mereu negasit cautat

De ti-as putea cunoaste numele asa cum
  
vocea ti-am cunoscut-o d-inaintea tacerii&#8230;<!--more-->

Ne pregatim pentru o ultima ploaie violet;
  
ne asteapta ploile verzi din marile muzicale
  
Nu ma stii&#8230; Nu m-am stiut niciodata!