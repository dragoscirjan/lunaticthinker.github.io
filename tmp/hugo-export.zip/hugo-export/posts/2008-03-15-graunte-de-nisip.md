---
title: graunte de nisip
author: dragos
type: post
date: 2008-03-15T11:45:15+00:00
url: /index.php/graunte-de-nisip/
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
Cand oamenii au creat lumea din urma
  
El privea deja spre apus, asezat
  
in varvul unei piramite in desert&#8230;
  
&#8211; era mai aproape acum&#8230; atat de aproape
  
de toti acei zei pe care ii dispretuise.
  
Era tanar cand lumea dintai se nascuse
  
&#8211; prea mandru de propria-i stea
  
in ale carei colturi intrezarise deja omul

Dar omul nu sa dovedit niciodata minunea &#8211;<!--more-->


  
focul pe care il astepta. Zeii jucasera
  
inca o data tabinet cartile lui&#8230;

Acum, lumea dintai era un graunte de nisip
  
&#8220;O picatura de Mercur, altauri de
  
trei prafuri de femeie,&#8230; al saselea colt
  
al unei stele si inelele celui de-al noua zeu&#8230;
  
Toate alaturi de&#8230;&#8221;

Nu erau amintiri&#8230; El, firul de vant
  
devenise acum calatorul&#8230;
  
una din fiintele acelea eterne&#8230;
  
traind mereu pe o frantura de streasina
  
a unei pleoape intredeschise&#8230;

Avea ochii inchisi insa lumea&#8230;
  
Lumea era doar un graunte de nisip.

2008,02,25