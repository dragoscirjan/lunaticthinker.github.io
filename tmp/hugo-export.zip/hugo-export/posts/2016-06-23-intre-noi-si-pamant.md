---
title: Intre noi si pamant
author: dragos
type: post
date: 2016-06-23T15:02:47+00:00
url: /index.php/intre-noi-si-pamant/
categories:
  - In bezna

---
Intre noi si pamant
  
erau luna si cerul si norii
  
si mormantul lui Dumnezeu

Copii jucau aievea, rugi

Tu arzi precum vapaia unui rug
  
si dansul in care ma inchin&#8230;
  
Si nu te stingi! Si-am vrut
  
sa musc din flacari din ziua-ntai!

Tu erai luna; eu acel chip de clei
  
Privind in fiecare noapte cum rasai
  
Visand sa zbor, sa ma inec in nori
  
Si-apoi sa cad in unicul mormant

Intre noi si pamant
  
E seara iar