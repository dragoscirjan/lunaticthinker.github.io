---
title: Do you think of me?
author: dragos
type: post
date: 2012-02-06T21:25:15+00:00
url: /index.php/do-you-think-of-me/
categories:
  - Red Wine

---
you give me a quiet mind
  
and I&#8230; I&#8230;

Do you think of me?

I kissed her on the cheek today
  
And she smiled; I feel like a child!
  
My heart gives me chills; I have butterflies &#8211;
  
there&#8217;s a light at the end of the dark
  
and it&#8217;s the smell of her skin<!--more-->

Do you think of me?

Forgive the roses my love; you said
  
Sometimes they are beautiful &#8211;
  
Sometimes they sting

All beauty can kill; I replied in my head;
  
yet I was ready to bleed in her arms;
  
No matter the thorns or the pain &#8211;
  
She&#8217;s like no other rose I have seen
  
And roses bleed too