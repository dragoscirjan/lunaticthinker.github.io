---
title: Dimineata fumez vise
author: dragos
type: post
date: 2008-03-16T01:45:40+00:00
url: /index.php/dimineata-fumez-vise/
featured_image: http://lunaticthinker.me/wp-content/uploads/2008/03/women_smoking_black_cigarettes_desktop_1440x900_wallpaper-396834.jpg
categories:
  - Art of Life
  - Azi soarele a apus pe dos

---
<p style="font-size: 80%; padding-left: 50px" align="right">
  Am decis sa imi las unghiile sa creasca<br /> doar ca sa pot scurma cu mai multa forta<br /> dupa gandurile tale atat de ingropate.
</p>

Dimineata, cand ma trezesc, fumez vise &#8211;
  
doua pachete: unul cu aroma de cirese
  
si celalalt &#8221;long&#8221; / Kent Long&#8230;
  
Dupa masa fumez iubiri &#8211; recomandarea
  
doctorului: intre una si trei pe zi&#8230;
  
Eu le fumez pe toate odata.
  
Asa nu am sa uit de ce mi te-am ales soata&#8230;<!--more-->


  
Seara pufaim amandoi&#8230; din aceeasi pipa
  
Ne tragem sufletul&#8230; odihna cea din urma&#8230;
  
Noaptea imi inmormantez plamanii alaturi de tine
  
Tu ma iei in brate si imi gusti buzele vinete
  
In sfarsit singuri pentru totdeauna&#8230;
  
ingropati in scrum.

Mi-e frica sa nu vina iarasi dimineata&#8230;

2007,08,26