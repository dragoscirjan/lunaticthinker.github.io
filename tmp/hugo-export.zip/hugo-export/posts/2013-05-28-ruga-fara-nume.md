---
title: Ruga fara nume
author: dragos
type: post
date: 2013-05-28T00:10:38+00:00
url: /index.php/ruga-fara-nume/
featured_image: http://lunaticthinker.me/wp-content/uploads/2013/05/black-roses-burning-sculpture.jpg
categories:
  - Art of Life
  - O linie franta in doi

---
Cum as putea sa desenez fluturi
  
In calea unui fir de vis, ce moare &#8211;
  
Cum as putea sa-ti arat sufletul
  
Cand l-am inchis dupa atatea gratii
  
Cum as putea sa-ti intind mana intru izbavire
  
Cand singura icoana de-am sa pot s-o port
  
E bestia informetata sadindu-si cuib in mine&#8230;

Mi-am tatuat visul pe spate in propriul sange
  
Caci nebunia mi-a ramas ca ultim loc in care<!--more-->


  
Respir; si pot fi eu; si pot fi drumul tau
  
de vindecare! Am sa sadesc o usa cu flori
  
de foc si ghimpi; si inca-o usa &#8211; si inca una
  
Pana ce va ramane ingropat si-am sa pot fi nou
  
Si-am sa fiu sprijin in calea franturilor din lume
  
Si n-a sa-mi fie foame! Si n-am sa fur din tine
  
Cand crucea va fi arsa, iar tu ai sa rasai din nou&#8230;