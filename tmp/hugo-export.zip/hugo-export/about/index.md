---
title: About
author: admin
type: page
date: 2015-12-24T12:01:56+00:00
eltd_disable_footer_meta:
  - no
eltd_hide_background_image_meta:
  - no
eltd_show_title_area_meta:
  - no
eltd_page_padding_meta:
  - 0px 0px

---
\[vc\_row\]\[vc\_column\]\[vc\_single\_image image=&#8221;3248&#8243; img\_size=&#8221;full&#8221;\]\[/vc\_column\]\[/vc\_row\]\[vc\_row\][vc_column]

<div class="eltd-elements-holder eltd-responsive-mode-768" >
  <div class="eltd-elements-holder-item "  >
    <div class="eltd-elements-holder-item-inner">
      <div class="eltd-elements-holder-item-content eltd-elements-holder-custom-941640" style="padding: 0 20px">
        [vc_empty_space height=&#8221;38&#8243;]
        
        <div class="eltd-section-title-outer-holder" style="text-align: left">
          <div class="eltd-section-title-holder">
            <div class="eltd-section-title" style=";">
              About me
            </div>
          </div>
        </div>[vc_empty_space height=&#8221;5&#8243;][vc_column_text]</p> 
        
        <h4>
          HELLO! I’M SELENA RICHARDSON.
        </h4>
        
        <p>
          [/vc_column_text][vc_empty_space height=&#8221;30&#8243;] <div class="eltd-custom-font-holder" style="font-family: Open Sans;font-size: 18px;line-height: 24px;font-weight: 400;letter-spacing: 0px;color: #444444" data-font-size= 18 data-line-height= 24> This section contains many common flower varieties that can often be found at your local professional florist. With an expanding global.</div>[vc_empty_space height=&#8221;10&#8243;][vc_column_text]Lorem ipsum dolor sit amet, lacus eu erat integer bibendum rutrum, sed arcu molestie, in quis ornare, rhoncus sceleris nam feugiat nibh leo. Ac suspendisse turpis posuere, cursus fames eu eget dolorem sapien. Eget cras urna nam, ultricies proin interdum facilisis arcu, eget sed quam enim nam, sit pede nonummy viverra dolor sed orci, nec feugiat donec phasellus. Arcu litora gravida, eget ac, magna in aut proin congue, ac at justo wisi. Adipiscing nam et ac at ipsum. Ac id sit pharetra lorem ultrices, cum erat arcu non urna amet sodales, mauris odio, vestibulum nulla quisque ac metus, quam nostra a qui. Risus atque amet dignissim, est elit suspendisse adipiscing, sapien lectus in nulla vitae imperdiet massa, placerat luctus.[/vc_column_text][vc_empty_space height=&#8221;23&#8243;] <span class="eltd-icon-shortcode normal" style="margin: 0 20px 0 0" > <a href="https://vimeo.com/" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_vimeo eltd-icon-element" style="font-size:12px" ></span> </a> </span> <span class="eltd-icon-shortcode normal" style="margin: 0 20px 0 0" > <a href="http://instagram.com" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_instagram eltd-icon-element" style="font-size:12px" ></span> </a> </span> <span class="eltd-icon-shortcode normal" style="margin: 0 20px 0 0" > <a href="" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_twitter eltd-icon-element" style="font-size:12px" ></span> </a> </span> <span class="eltd-icon-shortcode normal"  > <a href="https://www.pinterest.com" target="_self"> <span aria-hidden="true" class="eltd-icon-font-elegant social_pinterest eltd-icon-element" style="font-size:12px" ></span> </a> </span> </div> </div> </div></div>[/vc_column][/vc_row]
        </p>